function Contact() {
    return (
        <p>this is Contact  page</p>
    )
} export default Contact